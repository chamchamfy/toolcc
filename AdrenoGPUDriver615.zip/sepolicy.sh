# debug
magiskpolicy --live "dontaudit system_server system_file file write"
magiskpolicy --live "allow     system_server system_file file write"

# context
magiskpolicy --live "type system_lib_file"
magiskpolicy --live "type vendor_file"
magiskpolicy --live "type vendor_configs_file"
magiskpolicy --live "type hal_dms_default_exec"
magiskpolicy --live "type vendor_data_file"
magiskpolicy --live "type vendor_media_data_file"
magiskpolicy --live "type same_process_hal_file"
magiskpolicy --live "dontaudit { system_lib_file vendor_file vendor_configs_file hal_dms_default_exec vendor_data_file vendor_media_data_file same_process_hal_file } labeledfs filesystem associate"
magiskpolicy --live "allow     { system_lib_file vendor_file vendor_configs_file hal_dms_default_exec vendor_data_file vendor_media_data_file same_process_hal_file } labeledfs filesystem associate"
magiskpolicy --live "dontaudit init { system_lib_file vendor_file vendor_configs_file vendor_data_file vendor_media_data_file } dir relabelfrom"
magiskpolicy --live "allow     init { system_lib_file vendor_file vendor_configs_file vendor_data_file vendor_media_data_file } dir relabelfrom"
magiskpolicy --live "dontaudit init { system_lib_file vendor_file vendor_configs_file hal_dms_default_exec vendor_data_file vendor_media_data_file same_process_hal_file } file relabelfrom"
magiskpolicy --live "allow     init { system_lib_file vendor_file vendor_configs_file hal_dms_default_exec vendor_data_file vendor_media_data_file same_process_hal_file } file relabelfrom"